namespace Entities.Dtos
{
    public record ProductDtoForInsertion : ProductDto
    {
        
    }
}