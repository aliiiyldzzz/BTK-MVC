namespace Entities.RequestParameters
{
    public abstract class RequestParameters
    {
        public String? SearchTerm { get; set; }
    }
}