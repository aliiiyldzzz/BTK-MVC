﻿namespace Presentation
{
    public class AssemblyReference
    {

    }
}
